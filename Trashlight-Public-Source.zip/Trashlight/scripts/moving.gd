extends AnimatableBody2D
@export var travel = Vector2(0, -100)
@export var duration = 3.0
func _ready() -> void:
	var start = position
	var tween = create_tween().set_loops()
	tween.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tween.tween_property(self, "position", start + travel, duration)
	tween.tween_property(self, "position", start, duration)
