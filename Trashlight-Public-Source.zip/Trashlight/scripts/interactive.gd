extends Area2D
@export_enum("checkpoint", "exit", "hazard", "hint") var kind = "checkpoint"
@export_multiline var text = ""
var active = false
func _ready() -> void:
	body_entered.connect(entered)
func entered(body: Node2D) -> void:
	if not Session.playing or not body.visible or not body.is_in_group("player"):
		return
	match kind:
		"checkpoint":
			# Former checkpoint lamps are scenery only.
			return
		"exit":
			if Session.level in Session.fragments:
				get_tree().current_scene.advance()
			else:
				Session.message.emit("Find this area's power cell before leaving. Look for the golden diamond.")
		"hazard":
			body.hurt()
		"hint":
			if not active:
				active = true
				Session.message.emit(text)
