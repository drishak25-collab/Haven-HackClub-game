extends Node
signal changed
signal message(text: String)
signal pulse
var difficulty = 0
var saved_difficulty = 0
var at_boss = false
var boss_checkpoint = 0
var level = 0
var checkpoint = Vector2(100, 530)
var health = 3
var fireflies = 0
var fragments: Array[int] = []
var collected: Array[String] = []
var has_save = false
var playing = false
var muted = false
var sound_bank: Dictionary = {}
const LEVELS = ["res://levels/forest.tscn", "res://levels/village.tscn", "res://levels/beacon.tscn", "res://levels/sludge.tscn"]
const TITLES = ["01  /  THE DRAIN", "02  /  THE SCRAPYARD", "03  /  THE SMOKESTACK", "04  /  FLOOD SHAFT"]

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	bind("left", [KEY_A, KEY_LEFT])
	bind("right", [KEY_D, KEY_RIGHT])
	bind("jump", [KEY_SPACE, KEY_W, KEY_UP])
	bind("pulse", [KEY_X, KEY_E])
	bind("dash", [KEY_SHIFT, KEY_C])
	bind("pause", [KEY_ESCAPE, KEY_P])
	for entry in [["jump", 370.0, 0.12], ["pickup", 930.0, 0.15], ["pulse", 230.0, 0.5], ["hurt", 140.0, 0.25], ["checkpoint", 600.0, 0.35], ["win", 800.0, 0.65]]:
		make_sound(entry[0], entry[1], entry[2])
	sound_bank["explosion"] = load("res://audio/reactor-blast.wav")
	var cfg = ConfigFile.new()
	if cfg.load("user://trashlight.cfg") == OK:
		difficulty = clampi(int(cfg.get_value("save", "difficulty", 0)),0,1)
		saved_difficulty = difficulty
		at_boss = bool(cfg.get_value("save", "at_boss", false))
		boss_checkpoint = clampi(int(cfg.get_value("save", "boss_checkpoint", 0)), 0, 1)
		has_save = bool(cfg.get_value("save", "active", false))
		level = clampi(int(cfg.get_value("save", "level", 0)), 0, 3)
		checkpoint = cfg.get_value("save", "checkpoint", Vector2(100, 530))
		fireflies = int(cfg.get_value("save", "fireflies", 0))
		for f in cfg.get_value("save", "fragments", []):
			fragments.append(int(f))
		for id in cfg.get_value("save", "collected", []):
			collected.append(str(id))
		muted = bool(cfg.get_value("save", "muted", false))

	# Old mid-level saves no longer act as checkpoints; boss arrival stays compatible.
	boss_checkpoint = 0
	if not at_boss:
		level = 0
		checkpoint = Vector2(100,530)
		fireflies = 0
		fragments.clear()
		collected.clear()

func bind(action: String, keys: Array) -> void:
	InputMap.add_action(action)
	for key in keys:
		var event = InputEventKey.new()
		event.physical_keycode = key
		InputMap.action_add_event(action, event)

func reset_run() -> void:
	at_boss = false
	boss_checkpoint = 0
	level = 0
	checkpoint = Vector2(100, 530)
	health = 3
	fireflies = 0
	fragments.clear()
	collected.clear()
	playing = true
	save_run()

func save_run(active: bool = true) -> void:
	has_save = active
	saved_difficulty = difficulty
	var cfg = ConfigFile.new()
	var stored_level = level if at_boss else 0
	var stored_spawn = checkpoint if at_boss else Vector2(100,530)
	var stored_scrap = fireflies if at_boss else 0
	var stored_fragments = fragments if at_boss else []
	var stored_collected = collected if at_boss else []
	for item in [["difficulty", difficulty], ["at_boss", at_boss], ["boss_checkpoint", 0], ["active", active], ["level", stored_level], ["checkpoint", stored_spawn], ["fireflies", stored_scrap], ["fragments", stored_fragments], ["collected", stored_collected], ["muted", muted]]:
		cfg.set_value("save", item[0], item[1])
	cfg.save("user://trashlight.cfg")

func collect(id: String, is_fragment: bool) -> void:
	if id in collected:
		return
	collected.append(id)
	if is_fragment:
		if level not in fragments:
			fragments.append(level)
		message.emit("POWER CELL FOUND  ·  Bring it to the gate")
		sound("win")
	else:
		fireflies += 1
		if fireflies % 5 == 0:
			health = mini(3, health + 1)
			message.emit("Five scrap pieces. Somehow that fixed a heart.")
		sound("pickup")
	changed.emit()

func make_sound(key: String, hz: float, duration: float) -> void:
	var wav = AudioStreamWAV.new()
	wav.format = AudioStreamWAV.FORMAT_16_BITS
	wav.mix_rate = 22050
	var bytes = PackedByteArray()
	for i in range(int(duration * 22050)):
		var t = float(i) / 22050.0
		var env = pow(1.0 - t / duration, 2) * minf(t * 120, 1)
		var sample_value = int((sin(TAU * hz * t * (1 + t * 0.2)) + 0.25 * sin(TAU * hz * 1.5 * t)) * env * 6000)
		bytes.append(sample_value & 255)
		bytes.append((sample_value >> 8) & 255)
	wav.data = bytes
	sound_bank[key] = wav

func sound(key: String) -> void:
	if muted:
		return
	var p = AudioStreamPlayer.new()
	p.stream = sound_bank[key]
	p.volume_db = -8
	add_child(p)
	p.finished.connect(p.queue_free)
	p.play()
