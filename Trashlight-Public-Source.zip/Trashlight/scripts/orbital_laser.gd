extends Area2D
## Fixed, full-height strike. Aim locks before charging; the warning footprint equals damage.
@export var size = Vector2(66,650)
@export var warning_seconds = 1.1
@export var active_seconds = 0.65
var travel_velocity = Vector2.ZERO
var kind = "laser"
var age = 0.0
var active = false
var cancelled = false
var laser_sprite: AnimatedSprite2D
func _ready() -> void:
	collision_layer = 0
	collision_mask = 2
	z_index = 5
	$Art.hide()
	var shape = RectangleShape2D.new()
	shape.size = size
	$CollisionShape2D.shape = shape
	laser_sprite = $Beam
	laser_sprite.sprite_frames = preload("res://art/fx/orbital.tres")
	laser_sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	laser_sprite.rotation = 0
	laser_sprite.scale = Vector2(size.x/32.0,size.y/256.0)
	laser_sprite.visible = true
	laser_sprite.play("charge")
	add_to_group("boss_hazards")
func _physics_process(dt: float) -> void:
	if cancelled or not Session.playing:
		return
	age += dt
	var was_active = active
	active = age >= warning_seconds
	laser_sprite.visible = true
	laser_sprite.modulate = Color(1,1,1,1.0 if active else 0.25+0.15*clampf(age/warning_seconds,0,1))
	if active:
		if not was_active:
			laser_sprite.play("strike")
			Session.sound("explosion")
			var impact = preload("res://scenes/sprite_fx.tscn").instantiate()
			impact.effect = "hit"
			impact.position = Vector2(0,size.y/2-12)
			impact.scale = Vector2(3,2)
			add_child(impact)
		for body in get_overlapping_bodies():
			if body.is_in_group("player"):
				body.hurt()
	if age >= warning_seconds + active_seconds:
		queue_free()
	queue_redraw()
func _draw() -> void:
	if active:
		return
	var half = size.x/2
	var floor_y = size.y/2
	var progress = clampf(age/warning_seconds,0,1)
	var ink = Color(0.86,0.74,0.49,0.42+progress*0.16)
	# Quiet lane shading and two short floor ticks mark the exact damage width.
	draw_rect(Rect2(-half,-floor_y,size.x,size.y),Color(0.8,0.66,0.4,0.025+progress*0.015))
	for side in [-1,1]:
		var foot = Vector2(side*half,floor_y-3)
		draw_line(foot,foot+Vector2(-side*7,0),ink,2,false)
		draw_line(foot,foot+Vector2(0,-7),ink,2,false)
	# A small floor charge cue fills once; no arrows, scanning lines or labels.
	draw_line(Vector2(-half,floor_y-1),Vector2(-half+size.x*progress,floor_y-1),Color(0.92,0.8,0.55,0.55),2,false)
