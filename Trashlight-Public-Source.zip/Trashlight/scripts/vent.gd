extends Area2D
## Amber wind-up, damaging steam, then a safe cooldown.
@export var cycle = 3.6
@export var phase_offset = 0.0
var steam_sprite: Node2D
var age = 0.0
var active = false
func _ready() -> void:
	collision_layer = 0
	collision_mask = 2
	$Steam.hide()
	steam_sprite = preload("res://scenes/sprite_fx.tscn").instantiate()
	steam_sprite.effect = "steam"
	steam_sprite.looping = true
	steam_sprite.position = Vector2(0,-42)
	if Session.level < 3:
		steam_sprite.position = Vector2(0,-105)
	steam_sprite.scale = Vector2(2.6,3.5) if Session.level < 3 else Vector2(1.5,1.4)
	add_child(steam_sprite)
func _physics_process(dt: float) -> void:
	if not Session.playing:
		return
	age += dt
	var t = fmod(age + phase_offset, cycle * (0.75 if Session.difficulty == 1 else 1.0))
	active = t >= (0.6 if Session.difficulty == 1 else 0.85) and t < 1.65
	steam_sprite.visible = active
	$Warning.visible = t < (0.6 if Session.difficulty == 1 else 0.85)
	if active:
		for b in get_overlapping_bodies():
			if b.is_in_group("player"):
				b.hurt()
