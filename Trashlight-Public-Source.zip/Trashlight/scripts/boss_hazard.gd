extends Area2D
## Reusable native Area2D hazard. Amber outlines always precede damage.
@export var size = Vector2(80, 180)
@export var warning_seconds = 0.9
@export var active_seconds = 0.7
@export var travel_velocity = Vector2.ZERO
@export_enum("crusher", "laser", "scrap", "spike") var kind = "crusher"
const SPRITE_FX = preload("res://scenes/sprite_fx.tscn")
var spike_sprite: AnimatedSprite2D
var laser_sprite: AnimatedSprite2D
var age = 0.0
var active = false
var cancelled = false
@onready var art: Polygon2D = $Art
func _ready() -> void:
	collision_layer = 0
	collision_mask = 2
	var rect = RectangleShape2D.new()
	rect.size = size
	$CollisionShape2D.shape = rect
	art.polygon = PackedVector2Array([Vector2(-size.x/2, -size.y/2), Vector2(size.x/2, -size.y/2), size/2, Vector2(-size.x/2, size.y/2)])
	add_to_group("boss_hazards")
	if kind == "spike":
		art.hide()
		var triangle = ConvexPolygonShape2D.new()
		triangle.points = PackedVector2Array([Vector2(-12,-24),Vector2(12,-24),Vector2(0,25)])
		$CollisionShape2D.shape = triangle
		spike_sprite = AnimatedSprite2D.new()
		spike_sprite.sprite_frames = preload("res://art/fx/spike.tres")
		spike_sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		add_child(spike_sprite)
		spike_sprite.play("fall")
	if kind == "laser":
		laser_sprite = AnimatedSprite2D.new()
		laser_sprite.sprite_frames = preload("res://art/fx/effects.tres")
		laser_sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		var vertical = size.y > size.x
		laser_sprite.rotation = PI/2 if vertical else 0.0
		laser_sprite.scale = Vector2(size.y/96.0,size.x/12.0) if vertical else Vector2(size.x/96.0,size.y/12.0)
		laser_sprite.visible = false
		add_child(laser_sprite)
		laser_sprite.play("laser")
func _physics_process(dt: float) -> void:
	if cancelled:
		return
	age += dt
	var was_active = active
	active = age >= warning_seconds
	if kind == "laser":
		laser_sprite.visible = active
		if active and not was_active:
			var flash = SPRITE_FX.instantiate()
			flash.effect = "muzzle"
			add_child(flash)
	if kind == "spike":
		spike_sprite.modulate.a = 1.0 if active else 0.3
	if active:
		position += travel_velocity * dt
		if kind == "spike" and position.y >= 630:
			var impact = SPRITE_FX.instantiate()
			impact.effect = "hit"
			impact.position = Vector2(position.x,640)
			get_parent().add_child(impact)
			queue_free()
			return
		art.color = Color.TRANSPARENT if kind == "laser" else Color("c7b469")
		for body in get_overlapping_bodies():
			if body.is_in_group("player"):
				body.hurt()
	else:
		art.color = Color(0.85, 0.69, 0.25, 0.08 + 0.12 * absf(sin(age * 8)))
	if age >= warning_seconds + active_seconds or position.y < -350 or position.y > 900 or position.x < -300 or position.x > 1452:
		queue_free()
	queue_redraw()
func interrupt() -> void:
	if kind == "scrap" or kind == "spike":
		cancelled = true
		queue_free()
func _draw() -> void:
	if kind == "spike":
		if not active:
			var y = 647-position.y
			draw_line(Vector2(-9,y),Vector2(9,y),Color(0.75,0.81,0.83,0.5),2)
		return
	var r = Rect2(-size/2, size)
	if not active:
		draw_rect(r, Color("dbb45f"), false, 2)
		for x in range(int(-size.x/2), int(size.x/2), 24):
			draw_line(Vector2(x, -size.y/2), Vector2(x+12, -size.y/2+12), Color("dbb45f"), 2)
	elif kind != "laser":
		draw_rect(r.grow(-4), Color("695b43"), false, 3)
