extends Node2D
## Deterministic boss state machine; all clocks stop when the game is paused.
const HAZARD = preload("res://scenes/boss_hazard.tscn")
const ATTACKS = ["ORBITAL INSPECTION", "ORBITAL SWEEP", "STEEL RAIN", "BLACKOUT BARRAGE", "REACTOR MELTDOWN"]
const LINES = ["Your shift ended three hours ago. That sounds like a you problem.", "A power outage is no excuse for leaving early.", "You broke company property. That comes out of your pay."]
var phase = 0
var checkpoint_phase = 0
var state = "intro"
var state_time = 0.0
var attack_index = 0
var wave_time = 0.0
var wave = 0
const MAX_HEALTH = 5
var health = max_health()
var invincible = 0.0
var testing = false
var finished = false
var pulse_flash = 0.0
var boss_age = 0.0
@onready var player = $Player
@onready var panel = $BossUI/Panel
@onready var fuse = $Fuse
@onready var darkness = $Darkness
@onready var attack_label = $BossUI/Panel/Attack
@onready var instruction = $BossUI/Panel/Instruction
@onready var dialogue = $BossUI/Panel/Dialogue

func _ready() -> void:
	Session.pulse.connect(on_pulse)
	var music = $Music.stream.duplicate() as AudioStreamWAV
	music.loop_mode = AudioStreamWAV.LOOP_FORWARD
	music.loop_begin = 0
	music.loop_end = int(music.get_length() * music.mix_rate)
	$Music.stream = music
	$Music.play()
	$BossUI/Retry/RetryButton.pressed.connect(retry)
	$BossUI/Retry/TitleButton.pressed.connect(return_title)
	$BossUI/Panel/TitleButton.pressed.connect(return_title)
	$BossUI/Panel/PauseButton.pressed.connect(func(): get_tree().current_scene.toggle_pause())
	$BossUI/Intro/Begin.pressed.connect(start_attacks)
	phase = 0
	checkpoint_phase = phase
	$BossUI/Retry.hide()
	$FinalStairs.hide()
	set_final_collision(false)
	fuse.hide()
	player.camera.enabled = false
	player.position = Vector2(576, 640)
	player.boss_arena = true
	$BossUI/Intro/Help.text = "SHIFT / C dashes through attacks. X hits exposed fuses.\nAmber rings warn before explosions. Beams strike top to floor.\nHARD: three hearts. Retry from start of boss." if Session.difficulty == 1 else "Five hearts. Three fuses. Retry from the start of the boss.\nSHIFT / C dash. X hits fuses. Amber blast rings warn before detonation.\nDodge orbital columns, steel spikes and reactor blasts."
	$BossUI/Intro/Subtitle.text = "Dodge the inspection. When the fuse opens, jump near it and press X."
	refresh()

func _physics_process(dt: float) -> void:
	if not Session.playing or finished:
		return
	boss_age += dt
	$Music.volume_db = -80.0 if Session.muted else -18.0
	invincible = maxf(0, invincible - dt)
	pulse_flash = maxf(0, pulse_flash - dt)
	$Foreman.position.y = 245 + sin(boss_age * 1.5) * 5
	$Foreman.rotation = sin(boss_age * 0.7) * 0.012
	player.position.x = clampf(player.position.x, 94, 1058)
	if state == "dead" or state == "intro":
		return
	state_time += dt
	if state == "attack":
		wave_time -= dt
		if wave_time <= 0:
			spawn_wave()
		if state_time >= 7.0 + phase:
			clear_hazards()
			attack_index += 1
			if attack_index >= 5:
				expose_fuse()
			else:
				begin_attack()
	elif state == "exposed":
		fuse.modulate.a = 0.75 + sin(boss_age * 7) * 0.25
		instruction.text = "FUSE OPEN — X   %ds" % ceili((7 if Session.difficulty == 1 else 10) - state_time)
		if state_time >= (7 if Session.difficulty == 1 else 10):
			attack_index = 0
			begin_attack()
	elif state == "phase_break":
		if state_time > 3.5:
			attack_index = 0
			begin_attack()
	elif state == "finale":
		wave_time -= dt
		if wave_time <= 0:
			var x = 200.0 + fmod(wave * 191.0, 740.0)
			spawn_orbital(x,48)
			wave += 1
			wave_time = 1.9
			spawn_spike_volley(4 if Session.difficulty == 0 else 7)
		if state_time >= 12:
			instruction.text = "CLIMB. X AT THE RED SWITCH."
	refresh()

func start_attacks() -> void:
	$BossUI/Intro.hide()
	health = max_health()
	attack_index = 0
	begin_attack()

func begin_attack() -> void:
	state = "attack"
	state_time = 0
	wave_time = 0.8
	wave = 0
	fuse.hide()
	darkness.visible = attack_index == 3
	attack_label.text = ATTACKS[attack_index]
	dialogue.text = LINES[phase]
	instruction.text = ["COLUMN LOCKED. LEAVE THE MARKED LANE BEFORE THE STRIKE.", "MOVE BETWEEN THE LOCKED ORBITAL LANES.", "STEEL RAIN. WATCH THE FLOOR MARKS. DASH THROUGH GAPS.", "KEEP MOVING. YOUR LANTERN STILL WORKS IN THE DARK.", "BLAST RINGS DETONATE. DASH OUT. ORBITAL STRIKES INCOMING."][attack_index]

func spawn_wave() -> void:
	# Fixed patterns make repeated attempts learnable, rather than random damage.
	match attack_index:
		0:
			var x = 160 + ((wave*199 + phase*61) % 830)
			spawn_orbital(x)
			if phase > 0 and wave % 2 == 0:
				spawn_orbital(1100-x,50)
			wave_time = 1.9 - phase*0.13
		1:
			for i in range(3 if Session.difficulty == 0 else 5):
				spawn_orbital(155 + ((i*205+wave*111)%835),50)
			wave_time = 2.0
		2:
			spawn_spike_volley(8 if Session.difficulty == 0 else 12)
			wave_time = 1.0 if Session.difficulty == 0 else 0.85
		3:
			spawn_spike_volley(5 if Session.difficulty == 0 else 8)
			spawn_orbital(180+((wave*211)%790),55)
			wave_time = 1.6

	# Later fuses combine patterns while retaining visible warning windows.
	if phase >= 1 and attack_index == 1 and wave % 2 == 1:
		spawn_orbital(180 + ((wave*211)%790),55)
	if phase == 2 and attack_index == 0 and wave % 2 == 0:
		spawn_spike_volley(4)
	if attack_index == 4:
		var x = 180 + ((wave * 229) % 790)
		spawn_blast(Vector2(x,600), 105 if Session.difficulty == 0 else 145)
		spawn_orbital(140 + ((wave*173)%850))
		if Session.difficulty == 1:
			spawn_blast(Vector2(1100-x,490),100)
		wave_time = 1.8 if Session.difficulty == 0 else 1.15
	wave_time *= 0.72 if Session.difficulty == 1 else 1.0
	wave += 1

func spawn_spike_volley(count: int) -> void:
	# Permuted lanes avoid piling every projectile into a single column.
	# Two adjacent lanes remain clear in each volley; dash can cross older waves.
	var safe_lane = (wave*5+phase*3)%16
	var spawned = 0
	for i in range(18):
		var lane = (i*7+wave*3)%18
		if lane == safe_lane or lane == safe_lane+1:
			continue
		var speed = 410 + phase*40
		spawn_hazard(Vector2(125+lane*53,-42-(spawned%3)*34),Vector2(24,49),0.8,3.2,Vector2(0,speed),"spike")
		spawned += 1
		if spawned >= count:
			break

func spawn_orbital(x: float, beam_width: float = 66.0) -> Node2D:
	var strike = preload("res://scenes/orbital_laser.tscn").instantiate()
	strike.position = Vector2(clampf(x,115,1035),325)
	strike.size = Vector2(beam_width * (1.25 if Session.difficulty == 1 else 1.0),650)
	strike.warning_seconds = 0.85 if Session.difficulty == 1 else 1.2
	strike.active_seconds = 0.75 if Session.difficulty == 1 else 0.55
	$Hazards.add_child(strike)
	return strike

func spawn_blast(at: Vector2, blast_radius: float) -> Node2D:
	var effect = Node2D.new()
	effect.set_script(preload("res://scripts/explosion.gd"))
	effect.position = at
	effect.radius = blast_radius
	effect.warning = 0.8 if Session.difficulty == 1 else 1.15
	$Hazards.add_child(effect)
	return effect

func max_health() -> int:
	return 3 if Session.difficulty == 1 else MAX_HEALTH

func spawn_hazard(at: Vector2, dimensions: Vector2, warning: float, duration: float, speed: Vector2 = Vector2.ZERO, kind: String = "crusher") -> Node2D:
	var h = HAZARD.instantiate()
	h.position = at
	h.size = dimensions
	h.warning_seconds = warning * (0.72 if Session.difficulty == 1 else 1.0)
	h.active_seconds = duration
	h.travel_velocity = speed * (1.25 if Session.difficulty == 1 else 1.0)
	h.kind = kind
	$Hazards.add_child(h)
	return h

func clear_hazards() -> void:
	for h in $Hazards.get_children():
		h.set_physics_process(false)
		$Hazards.remove_child(h)
		h.queue_free()
	darkness.hide()

func expose_fuse() -> void:
	state = "exposed"
	state_time = 0
	clear_hazards()
	player.cooldown = 0
	fuse.position = [Vector2(240, 480), Vector2(912, 480), Vector2(576, 480)][phase]
	fuse.show()
	attack_label.text = "OVERTEMP / FUSE EXPOSED"
	dialogue.text = "Do not touch that. It is clearly labeled 'do not touch'."
	instruction.text = "JUMP NEAR THE GOLD FUSE AND PRESS X"

func on_pulse() -> void:
	if not Session.playing or state == "dead" or state == "intro":
		return
	pulse_flash = 0.4
	for h in $Hazards.get_children():
		if h.position.distance_to(player.position - Vector2(0, 22)) < 230:
			if h.has_method("interrupt"):
				h.interrupt()
	if state == "exposed" and player.position.distance_to(fuse.position) < 115:
		break_fuse()
	elif state == "finale" and player.position.distance_to($Shutoff.position) < 105:
		win()

func break_fuse() -> void:
	if state != "exposed":
		return
	phase += 1
	Session.sound("win")
	fuse.hide()
	clear_hazards()
	health = mini(max_health(), health + 1)
	if phase >= 3:
		start_finale()
	else:
		state = "phase_break"
		state_time = 0
		attack_label.text = "FUSE %d DESTROYED" % phase
		instruction.text = "ONE HEART RESTORED"
		dialogue.text = "This is going on your permanent record."
	refresh()

func start_finale() -> void:
	state = "finale"
	state_time = 0
	wave_time = 2
	wave = 0
	clear_hazards()
	$FinalStairs.show()
	set_final_collision(true)
	$Shutoff.show()
	attack_label.text = "ONE LAST THING"
	instruction.text = "CLIMB. X AT THE RED SWITCH."
	dialogue.text = "You cannot clock out if there is no clock."

func set_final_collision(enabled_value: bool) -> void:
	for body in $FinalStairs.get_children():
		if body is StaticBody2D:
			body.collision_layer = 1 if enabled_value else 0

func damage_player() -> void:
	if player.dash_time > 0 or invincible > 0 or state in ["dead", "intro", "phase_break"] or finished:
		return
	health -= 1
	invincible = 0.5 if Session.difficulty == 1 else 0.8
	player.invincible = 0.5 if Session.difficulty == 1 else 0.8
	Session.sound("hurt")
	if health <= 0:
		state = "dead"
		clear_hazards()
		Session.playing = false
		$BossUI/Retry.show()
		$BossUI/Retry/Subtitle.text = "Retry from the start of this boss. Your adventure checkpoint is safe."
	refresh()

func retry() -> void:
	clear_hazards()
	phase = 0
	health = max_health()
	invincible = 1.5
	player.invincible = 1.5
	player.cooldown = 0
	player.dash_time = 0
	player.dash_cooldown = 0
	player.position = Vector2(576, 640)
	player.velocity = Vector2.ZERO
	Session.playing = true
	$BossUI/Retry.hide()
	$FinalStairs.hide()
	set_final_collision(false)
	$Shutoff.hide()
	attack_index = 0
	begin_attack()

func refresh() -> void:
	instruction.visible = state in ["exposed","phase_break","finale"]
	$BossUI/Panel/Health.text = "♥ ".repeat(maxi(0, health))
	$BossUI/Panel/Fuses.text = "FUSES %d / 3  ·  %s" % [mini(phase, 3), ("HARD" if Session.difficulty == 1 else "EASY") + (" / TEST" if testing else " / FINAL")]
	$BossUI/Panel/Cooldown.text = ("SHIFT READY" if player.dash_cooldown <= 0 else "DASH %.1fs" % player.dash_cooldown) + (" / X READY" if player.cooldown <= 0 else " / X %.1fs" % player.cooldown)
	$Foreman.modulate = Color("e6b899") if state == "exposed" else Color.WHITE

func return_title() -> void:
	get_tree().current_scene.to_menu()

func win() -> void:
	if finished:
		return
	finished = true
	$Music.stop()
	clear_hazards()
	get_tree().current_scene.boss_won()

func _unhandled_key_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_M:
		Session.muted = not Session.muted
		$Music.volume_db = -80.0 if Session.muted else -18.0
