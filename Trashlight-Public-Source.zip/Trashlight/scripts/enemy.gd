extends CharacterBody2D
@export var patrol_distance = 110.0
@export var flying = false
const BLAST = preload("res://scripts/explosion.gd")
@export var bomber = false
var bomb_clock = 2.0
var origin = Vector2.ZERO
var direction = -1.0
var stunned = 0.0
var age = 0.0
var dead = false
func _ready() -> void:
	origin = position
	add_to_group("enemies")
	$Contact.body_entered.connect(touch)
func _physics_process(dt: float) -> void:
	if dead:
		return
	age += dt
	if bomber and Session.playing and stunned <= 0:
		bomb_clock -= dt
		var target = get_tree().get_first_node_in_group("player")
		if bomb_clock <= 0 and target and global_position.distance_to(target.global_position) < 430:
			var blast = Node2D.new()
			blast.set_script(BLAST)
			blast.position = target.global_position - Vector2(0,20)
			blast.radius = 115 if Session.difficulty == 1 else 90
			blast.warning = 0.8 if Session.difficulty == 1 else 1.2
			get_parent().add_child(blast)
			bomb_clock = 2.6 if Session.difficulty == 1 else 4.5
	$Art.self_modulate = Color("edb079") if bomber else Color.WHITE
	stunned = maxf(0, stunned - dt)
	$Art.modulate = Color("b1e8c1") if stunned > 0 else Color.WHITE
	if stunned > 0:
		velocity.x = 0
	else:
		velocity.x = direction * (94 if flying else 72) * (1.45 if Session.difficulty == 1 else 1.0)
	if flying:
		velocity.y = cos(age * 2.3) * 45
	else:
		velocity.y += 1250 * dt
	if absf(position.x - origin.x) > patrol_distance or is_on_wall():
		direction = -1 if position.x > origin.x else 1
	$Art.flip_h = direction > 0
	move_and_slide()
	var player = get_tree().get_first_node_in_group("player")
	if player and position.distance_to(player.position) < 34:
		touch(player)
func touch(body: Node2D) -> void:
	if dead or not body.is_in_group("player"):
		return
	if body.velocity.y > 60 and body.global_position.y < global_position.y - 10:
		dead = true
		var poof = preload("res://scenes/sprite_fx.tscn").instantiate()
		poof.effect = "hit"
		poof.position = global_position - Vector2(0,15)
		poof.scale = Vector2(2,2)
		get_parent().add_child(poof)
		body.velocity.y = -385
		Session.sound("pickup")
		var tween = create_tween()
		tween.tween_property(self, "scale", Vector2(1.25, 0.1), 0.12)
		tween.tween_callback(queue_free)
	elif stunned <= 0:
		body.hurt()
func stun() -> void:
	stunned = 3.5
