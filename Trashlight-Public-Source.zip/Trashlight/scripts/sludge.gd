extends Node2D
## A rising flood. Drowning ends the run; there are no recovery checkpoints.
var surface_y = 3460.0
var grace = 4.0
var age = 0.0
var drowned = false
@onready var player = $Player
func _ready() -> void:
	reset_flood()
func reset_flood() -> void:
	surface_y = 3460.0
	grace = 2.0 if Session.difficulty == 1 else 3.5
	age = 0
	drowned = false
func _physics_process(dt: float) -> void:
	if not Session.playing or not player.visible:
		return
	age += dt
	grace = maxf(0, grace - dt)
	if grace <= 0:
		surface_y -= (minf(98, 80 + age * 0.35) if Session.difficulty == 1 else minf(63, 50 + age * 0.18)) * dt
	$Sludge.position.y = surface_y
	$Sludge/Surface.position.x = sin(age * 2.0) * 6
	if player.position.y > surface_y + 4 and not drowned:
		drowned = true
		player.hurt(true)
	var gap = surface_y - player.position.y
	$FloodUI/Status.text = "SLUDGE %dm BELOW  ·  KEEP CLIMBING  ·  SHIFT / C DASH" % maxi(0,int(gap/10))
	$FloodUI/Status.modulate = Color("eea080") if gap < 140 else Color("d6dca3")
