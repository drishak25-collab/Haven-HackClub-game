extends CharacterBody2D
const SPEED = 255.0
const JUMP = -555.0
const GRAVITY = 1250.0
signal respawned
@export var boss_arena = false
@export var fall_limit = 850.0
const DASH_SPEED = 720.0
const DASH_DURATION = 0.16
const DASH_COOLDOWN = 1.05
var dash_time = 0.0
var dash_cooldown = 0.0
var dash_trail: Array[Vector2] = []
var coyote = 0.0
var jump_buffer = 0.0
var invincible = 0.0
var cooldown = 0.0
var pulse_time = 0.0
var facing = 1.0
var anim_time = 0.0
var respawning = false
@onready var art: Sprite2D = $Art
@onready var camera: Camera2D = $Camera2D

func _physics_process(dt: float) -> void:
	if not Session.playing:
		return
	anim_time += dt
	dash_time = maxf(0, dash_time - dt)
	dash_cooldown = maxf(0, dash_cooldown - dt)
	invincible = maxf(0, invincible - dt)
	cooldown = maxf(0, cooldown - dt)
	pulse_time = maxf(0, pulse_time - dt)
	jump_buffer = maxf(0, jump_buffer - dt)
	coyote = 0.12 if is_on_floor() else maxf(0, coyote - dt)
	if Input.is_action_just_pressed("jump"):
		jump_buffer = 0.14
	if jump_buffer > 0 and coyote > 0:
		velocity.y = JUMP
		jump_buffer = 0
		coyote = 0
		Session.sound("jump")
	if Input.is_action_just_released("jump") and velocity.y < -180:
		velocity.y *= 0.48
	var axis = Input.get_axis("left", "right")
	velocity.x = move_toward(velocity.x, axis * SPEED, (2100 if is_on_floor() else 1300) * dt)
	velocity.y = minf(velocity.y + GRAVITY * dt, 780)
	if axis != 0:
		facing = signf(axis)
	art.flip_h = facing < 0
	art.position.y = -23 + (sin(anim_time * 19) * 1.5 if is_on_floor() and absf(velocity.x) > 20 else 0)
	art.rotation = clampf(velocity.x / SPEED * 0.05, -0.05, 0.05)
	art.modulate.a = 0.4 if invincible > 0 and int(anim_time * 14) % 2 == 0 else 1.0
	if Input.is_action_just_pressed("pulse") and cooldown <= 0:
		cooldown = 1.8 if boss_arena else 4.0
		pulse_time = 0.65
		Session.pulse.emit()
		Session.sound("pulse")
		for enemy in get_tree().get_nodes_in_group("enemies"):
			if global_position.distance_to(enemy.global_position) < 230:
				enemy.stun()
	if Input.is_action_just_pressed("dash") and dash_cooldown <= 0:
		dash_time = DASH_DURATION
		var smoke = preload("res://scenes/sprite_fx.tscn").instantiate()
		smoke.effect = "smoke"
		smoke.position = global_position - Vector2(facing*10,12)
		smoke.scale = Vector2(1.5,1.5)
		get_parent().add_child(smoke)
		dash_cooldown = 1.4 if Session.difficulty == 1 else DASH_COOLDOWN
		Session.sound("jump")
	if dash_time > 0:
		velocity = Vector2(facing * DASH_SPEED, 0)
		dash_trail.push_front(global_position)
		if dash_trail.size() > 7:
			dash_trail.pop_back()
	elif not dash_trail.is_empty():
		dash_trail.pop_back()
	move_and_slide()
	position.x = maxf(20, position.x)
	if boss_arena:
		position.x = clampf(position.x, 94, 1058)
	if position.y > fall_limit:
		hurt(true)
	queue_redraw()

func _draw() -> void:
	for i in range(dash_trail.size()):
		var p = dash_trail[i] - global_position
		draw_rect(Rect2(p + Vector2(-15, -42), Vector2(30, 42)), Color(0.77, 0.92, 0.65, 0.3 * (1.0 - float(i) / 8)))
	if pulse_time > 0:
		var progress = 1.0 - pulse_time / 0.65
		draw_arc(Vector2(0, -24), 25 + progress * 225, 0, TAU, 80, Color(0.66, 0.94, 0.75, (1 - progress) * 0.85), 4, true)

func hurt(fall: bool = false) -> void:
	if dash_time > 0 and not fall:
		return
	if boss_arena:
		get_parent().damage_player()
		return
	if respawning or (invincible > 0 and not fall):
		return
	Session.health -= 1
	Session.sound("hurt")
	Session.changed.emit()
	if Session.health <= 0 or fall:
		respawning = true
		Session.health = 0
		Session.playing = false
		velocity = Vector2.ZERO
		get_tree().current_scene.call_deferred("restart_after_death")
		return
	else:
		velocity = Vector2(-facing * 210, -280)
	invincible = 0.85 if Session.difficulty == 1 else 1.5
	Session.changed.emit()
