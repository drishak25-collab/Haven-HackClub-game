extends Node2D
## Native reusable frame animation. Edit all sequences in effects.tres / SpriteFrames.
@export_enum("explosion", "laser", "smoke", "steam", "hit", "muzzle") var effect = "hit"
@export var looping = false
func _ready() -> void:
	$AnimatedSprite2D.play(effect)
	$AnimatedSprite2D.animation_finished.connect(finished)
func finished() -> void:
	if not looping:
		queue_free()
