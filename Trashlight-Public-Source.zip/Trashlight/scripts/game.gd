extends Node2D
var in_boss = false
var boss_testing = false
var world: Node2D
var player: CharacterBody2D
var message_time = 0.0
var menu = true
var ended = false
@onready var ui = $UI

func _ready() -> void:
	Session.playing = false
	$UI/Message.hide()
	$UI/Title/Start.pressed.connect(new_game)
	$UI/Title/Easy.pressed.connect(func(): select_difficulty(0))
	$UI/Title/Hard.pressed.connect(func(): select_difficulty(1))
	select_difficulty(Session.difficulty)
	$UI/Title/BossTest.pressed.connect(test_boss)
	$UI/Title/Continue.pressed.connect(continue_game)
	$UI/Title/Continue.disabled = not Session.has_save
	$UI/Pause/Resume.pressed.connect(toggle_pause)
	$UI/Pause/Menu.pressed.connect(to_menu)
	$UI/Ending/Again.pressed.connect(new_game)
	$UI/HUD/PauseButton.pressed.connect(toggle_pause)
	$UI/HUD/Sound.pressed.connect(toggle_sound)
	Session.changed.connect(update_hud)
	Session.message.connect(show_message)
	load_level(false)
	update_hud()
	if "--spike-preview" in OS.get_cmdline_user_args():
		call_deferred("spike_preview")
	if "--death-test" in OS.get_cmdline_user_args():
		call_deferred("run_death_tests")
	if "--route-test" in OS.get_cmdline_user_args():
		call_deferred("run_route_tests")
	if "--spike-test" in OS.get_cmdline_user_args():
		call_deferred("run_spike_tests")
	if "--orbital-test" in OS.get_cmdline_user_args():
		call_deferred("run_orbital_tests")
	if "--sprite-test" in OS.get_cmdline_user_args():
		call_deferred("run_sprite_tests")
	if "--effects-test" in OS.get_cmdline_user_args():
		call_deferred("run_effects_tests")
	if "--hard-test" in OS.get_cmdline_user_args():
		call_deferred("run_hard_tests")
	if "--sludge-preview" in OS.get_cmdline_user_args():
		call_deferred("sludge_preview")
	if "--boss-test" in OS.get_cmdline_user_args():
		call_deferred("run_boss_tests")
	if "--boss-preview" in OS.get_cmdline_user_args():
		call_deferred("boss_preview")
	if "--self-test" in OS.get_cmdline_user_args():
		call_deferred("run_tests")
	if "--preview" in OS.get_cmdline_user_args():
		call_deferred("previews")

func new_game() -> void:
	get_tree().paused = false
	Session.reset_run()
	boss_testing = false
	begin()
func continue_game() -> void:
	Session.difficulty = Session.saved_difficulty
	if not Session.at_boss:
		Session.reset_run()
	Session.health = 3
	Session.playing = true
	boss_testing = false
	begin()
func begin() -> void:
	menu = false
	ended = false
	$UI/Title.hide()
	$UI/Ending.hide()
	$UI/Pause.hide()
	$UI/HUD.show()
	if Session.at_boss:
		load_boss()
	else:
		in_boss = false
		load_level(true)
		show_message(Session.TITLES[Session.level] + "   ·   Find the power cell")
func load_level(with_player: bool) -> void:
	if is_instance_valid(world):
		remove_child(world)
		world.queue_free()
	world = load(Session.LEVELS[Session.level]).instantiate()
	world.process_mode = Node.PROCESS_MODE_PAUSABLE if with_player else Node.PROCESS_MODE_DISABLED
	add_child(world)
	player = world.get_node("Player")
	player.position = Session.checkpoint
	player.camera.limit_right = int(world.get_meta("width"))
	player.camera.limit_bottom = int(world.get_meta("height", 720))
	player.fall_limit = float(world.get_meta("height", 650)) + 200
	player.camera.limit_top = 0
	player.camera.limit_left = 0
	player.camera.enabled = true
	player.camera.reset_smoothing()
	player.visible = with_player
	update_hud()
func advance() -> void:
	if ended:
		return
	if Session.level == 3:
		Session.at_boss = true
		Session.boss_checkpoint = 0
		Session.save_run()
		call_deferred("load_boss")
	else:
		Session.level += 1
		Session.checkpoint = Vector2(120, 3200) if Session.level == 3 else Vector2(100, 530)
		Session.health = 3
		Session.save_run()
		call_deferred("load_next")
func load_next() -> void:
	load_level(true)
	show_message(Session.TITLES[Session.level] + "   ·   Follow the lanterns")
func _process(dt: float) -> void:
	if Input.is_action_just_pressed("pause") and not menu and not ended:
		toggle_pause()
	if not get_tree().paused and Session.playing and not in_boss:
		message_time = maxf(0, message_time - dt)
		$UI/Message.visible = message_time > 0
		if is_instance_valid(player):
			$UI/HUD/DashBar.value = clampf(1.0 - player.dash_cooldown / (1.4 if Session.difficulty == 1 else player.DASH_COOLDOWN),0,1)
			$UI/HUD/Pulse.text = ("SHIFT  DASH READY" if player.dash_cooldown <= 0 else "DASH %.1fs" % player.dash_cooldown) + ("  ·  X READY" if player.cooldown <= 0 else "  ·  X %.1fs" % player.cooldown)
			$UI/HUD/Pulse.modulate = Color("b7e8bd") if player.cooldown <= 0 else Color("9caeab")
func update_hud() -> void:
	$UI/HUD/HealthBar.value = Session.health
	$UI/HUD/Area.text = Session.TITLES[Session.level] + (" / HARD" if Session.difficulty == 1 else " / EASY")
	$UI/HUD/Hearts.text = "♥  " .repeat(maxi(0, Session.health))
	$UI/HUD/Count.text = "SCRAP  %02d    /    CELLS  %d / 4" % [Session.fireflies, Session.fragments.size()]
	$UI/HUD/Sound.text = "SOUND OFF" if Session.muted else "SOUND ON"
func show_message(text: String) -> void:
	if menu or in_boss:
		return
	$UI/Message/Text.text = text
	$UI/Message.show()
	message_time = 5.5
func toggle_pause() -> void:
	if menu or ended:
		return
	get_tree().paused = not get_tree().paused
	$UI/Pause.visible = get_tree().paused
func toggle_sound() -> void:
	Session.muted = not Session.muted
	Session.save_run(Session.has_save)
	update_hud()
func to_menu() -> void:
	if boss_testing:
		Session.difficulty = Session.saved_difficulty
	get_tree().paused = false
	if not boss_testing:
		Session.save_run()
	Session.playing = false
	Session.health = 3
	in_boss = false
	boss_testing = false
	menu = true
	ended = false
	$UI/Pause.hide()
	$UI/HUD.hide()
	$UI/Ending.hide()
	$UI/Message.hide()
	$UI/Title.show()
	$UI/Title/Continue.disabled = not Session.has_save
	select_difficulty(Session.difficulty)
	load_level(false)

func test_boss() -> void:
	boss_testing = true
	load_boss()

func load_boss() -> void:
	get_tree().paused = false
	menu = false
	ended = false
	in_boss = true
	Session.playing = true
	$UI/Title.hide()
	$UI/HUD.hide()
	$UI/Message.hide()
	$UI/Pause.hide()
	$UI/Ending.hide()
	if is_instance_valid(world):
		remove_child(world)
		world.queue_free()
	world = load("res://levels/foreman.tscn").instantiate()
	world.testing = boss_testing
	world.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(world)
	player = world.get_node("Player")

func boss_won() -> void:
	world.get_node("BossUI").hide()
	ended = true
	Session.playing = false
	if not boss_testing:
		Session.save_run(false)
	$UI/HUD.hide()
	$UI/Ending.show()
	$UI/Ending/Stats.text = "FOREMAN DEFEATED  /  3 FUSES DESTROYED" + ("  /  TEST RUN" if boss_testing else "")
	Session.sound("win")
	world.get_node("BossUI").hide()

func previews() -> void:
	var preview_save = FileAccess.get_file_as_bytes("user://trashlight.cfg")
	await get_tree().process_frame
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png(ProjectSettings.globalize_path("res://../Trashlight-title.png"))
	new_game()
	await get_tree().create_timer(0.3).timeout
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png(ProjectSettings.globalize_path("res://../Trashlight-play.png"))
	if not preview_save.is_empty():
		var f = FileAccess.open("user://trashlight.cfg", FileAccess.WRITE)
		f.store_buffer(preview_save)
		f.close()
	get_tree().quit()

func run_tests() -> void:
	Session.difficulty = 0
	var saved_bytes = FileAccess.get_file_as_bytes("user://trashlight.cfg")
	new_game()
	await get_tree().physics_frame
	assert(is_instance_valid(player) and world.get_meta("width") > 3000)
	# Landing uses real CharacterBody2D collisions.
	await get_tree().create_timer(0.7).timeout
	assert(player.is_on_floor(), "Player must land on opening ground")
	Input.action_press("jump")
	await get_tree().physics_frame
	await get_tree().physics_frame
	assert(player.velocity.y < 0, "Jump must rise")
	Input.action_release("jump")
	player.position = Vector2(100, 500)
	var ghost = world.get_node("GhostBridge1")
	assert(ghost.collision_layer == 0)
	Session.pulse.emit()
	assert(ghost.collision_layer == 1)
	var enemy = world.get_node("Beetle1")
	enemy.stun()
	assert(enemy.stunned > 0)
	Session.collect("test-firefly", false)
	assert(Session.fireflies == 1)
	Session.collect("test-firefly", false)
	assert(Session.fireflies == 1, "A pickup cannot be collected twice")
	Session.collect("test-fragment", true)
	assert(0 in Session.fragments)
	player.invincible = 0
	player.hurt()
	assert(Session.health == 2)
	Session.health = 3
	# Every scene must instantiate with all native collision nodes and scripts.
	for i in range(4):
		Session.level = i
		Session.checkpoint = Vector2(120, 3200) if i == 3 else Vector2(100, 530)
		load_level(true)
		await get_tree().physics_frame
		assert(world.has_node("Exit") and world.has_node("Fragment"))
		Session.collect("test-fragment-%d" % i, true)
	advance()
	await get_tree().process_frame
	assert(in_boss and world.has_node("Foreman"))
	world.win()
	assert(ended and $UI/Ending.visible)
	print("TRASHLIGHT: landing, jumping, ghost bridges, stun, pickups, respawn, four levels, boss transition and ending passed")
	Session.reset_run()
	Session.save_run(false)
	if not saved_bytes.is_empty():
		var restored_file = FileAccess.open("user://trashlight.cfg", FileAccess.WRITE)
		restored_file.store_buffer(saved_bytes)
		restored_file.close()
	await get_tree().create_timer(0.8).timeout
	get_tree().quit()

func boss_preview() -> void:
	await get_tree().process_frame
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png(ProjectSettings.globalize_path("res://../Trashlight-title.png"))
	test_boss()
	await get_tree().create_timer(0.15).timeout
	world.start_attacks()
	world.attack_index = 4
	world.begin_attack()
	world.spawn_wave()
	await get_tree().create_timer(1.25).timeout
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png(ProjectSettings.globalize_path("res://../Trashlight-boss.png"))
	get_tree().quit()

func run_boss_tests() -> void:
	Session.difficulty = 0
	# The test button must neither overwrite nor erase the player's saved campaign.
	var original_save = FileAccess.get_file_as_bytes("user://trashlight.cfg")
	var prior_progress = [Session.level, Session.at_boss, Session.boss_checkpoint, Session.fragments.duplicate(), Session.collected.duplicate()]
	$UI/Title/BossTest.pressed.emit()
	assert(in_boss and boss_testing and world.testing and world.state == "intro")
	var b = world
	b.set_physics_process(false)
	b.get_node("BossUI/Intro/Begin").pressed.emit()
	assert(b.state == "attack" and not b.get_node("BossUI/Intro").visible)
	await get_tree().create_timer(0.25).timeout
	# Real Area2D overlap: warning is harmless, active hit costs exactly one heart.
	var h = b.spawn_hazard(player.position - Vector2(0, 20), Vector2(70, 80), 0.2, 1.0)
	await get_tree().create_timer(0.09).timeout
	assert(b.health == 5 and not h.active)
	await get_tree().create_timer(0.22).timeout
	assert(b.health == 4 and h.active, "Active hazard must hurt")
	b.clear_hazards()
	b.invincible = 0
	# Every attack emits warned hazards, then transitions to an exposed fuse.
	for i in range(4):
		b.attack_index = i
		b.begin_attack()
		b.spawn_wave()
		assert(b.get_node("Hazards").get_child_count() > 0)
		for hazard in b.get_node("Hazards").get_children():
			assert(hazard.warning_seconds >= 0.6 and not hazard.active)
		b.clear_hazards()
	b.attack_index = 4
	b.begin_attack()
	b._physics_process(10)
	assert(b.state == "exposed")
	player.position = Vector2(100, 640)
	Session.pulse.emit()
	assert(b.phase == 0, "Out of range pulse cannot break a fuse")
	player.position = b.fuse.position + Vector2(0, 45)
	Session.pulse.emit()
	assert(b.phase == 1 and b.checkpoint_phase == 0)
	# Dying after fuse one retries at phase two, with six hearts and fresh cooldown.
	b.attack_index = 0
	b.begin_attack()
	b.health = 1
	b.invincible = 0
	b.damage_player()
	assert(b.state == "dead" and b.get_node("BossUI/Retry").visible)
	b.get_node("BossUI/Retry/RetryButton").pressed.emit()
	assert(b.phase == 0 and b.health == 5 and Session.playing)
	# Pause really suspends the arena and hazard clocks.
	b.set_physics_process(true)
	toggle_pause()
	var pause_clock = b.state_time
	await get_tree().create_timer(0.12).timeout
	assert(b.state_time == pause_clock)
	toggle_pause()
	b.set_physics_process(false)
	# Pulse destroys nearby falling scrap, but not crushers/lasers.
	var scrap = b.spawn_hazard(player.position, Vector2(24,24), 1.0, 1.0, Vector2.ZERO, "scrap")
	Session.pulse.emit()
	assert(scrap.cancelled)
	# Break the remaining fuses via the real pulse signal and activate the shutoff.
	for i in range(3):
		b.expose_fuse()
		player.position = b.fuse.position + Vector2(0,45)
		Session.pulse.emit()
	assert(b.phase == 3 and b.state == "finale")
	assert(b.get_node("FinalStairs/Step3").collision_layer == 1)
	player.position = b.get_node("Shutoff").position + Vector2(0,35)
	Session.pulse.emit()
	assert(ended and $UI/Ending.visible and b.finished)
	assert(original_save == FileAccess.get_file_as_bytes("user://trashlight.cfg"), "Boss shortcut must preserve save bytes")
	assert(prior_progress == [Session.level, Session.at_boss, Session.boss_checkpoint, Session.fragments, Session.collected])
	to_menu()
	assert(menu and not in_boss and not world.has_node("Foreman"))
	await get_tree().create_timer(0.25).timeout
	assert(original_save == FileAccess.get_file_as_bytes("user://trashlight.cfg"), "Returning from test arena must preserve saves too")
	print("BOSS CHECKS PASSED: shortcut, save preservation, warnings, damage, all patterns, fuse range, checkpoint, retry, pause, pulse interrupt, finale, victory, title return")
	await get_tree().create_timer(0.8).timeout
	get_tree().quit()

func sludge_preview() -> void:
	Session.level = 3
	Session.checkpoint = Vector2(120,3200)
	Session.playing = true
	menu = false
	$UI/Title.hide()
	$UI/HUD.show()
	load_level(true)
	await get_tree().create_timer(0.6).timeout
	world.surface_y = 3340
	await get_tree().physics_frame
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png(ProjectSettings.globalize_path("res://../Trashlight-sludge.png"))
	get_tree().quit()

func run_hard_tests() -> void:
	Session.difficulty = 0
	var original_save = FileAccess.get_file_as_bytes("user://trashlight.cfg")
	Session.level = 0
	Session.checkpoint = Vector2(100,530)
	Session.health = 3
	Session.playing = true
	menu = false
	$UI/Title.hide()
	load_level(true)
	await get_tree().create_timer(0.7).timeout
	assert(player.is_on_floor())
	Input.action_press("dash")
	await get_tree().physics_frame
	await get_tree().physics_frame
	Input.action_release("dash")
	assert(player.dash_time > 0 and absf(player.velocity.x) == player.DASH_SPEED)
	var before = Session.health
	player.hurt()
	assert(Session.health == before, "Dash should pass through attacks")
	await get_tree().create_timer(0.25).timeout
	assert(player.dash_time == 0 and player.dash_cooldown > 0)
	Input.action_press("dash")
	await get_tree().physics_frame
	await get_tree().physics_frame
	Input.action_release("dash")
	assert(player.dash_time == 0, "Cannot chain dashes during cooldown")
	await get_tree().create_timer(1.05).timeout
	assert(player.dash_cooldown == 0)
	# Existing stages contain timed vent hazards and extra enemy actors.
	for path in Session.LEVELS.slice(0,3):
		var packed = load(path).instantiate()
		assert(packed.has_node("SteamVent0") and packed.has_node("ExtraMoth"))
		packed.free()
	var vent = world.get_node("SteamVent0")
	vent.age = 0
	player.position = Vector2(480,590)
	player.velocity = Vector2.ZERO
	player.invincible = 0
	await get_tree().create_timer(0.1).timeout
	assert(not vent.active)
	await get_tree().create_timer(0.85).timeout
	assert(vent.active and Session.health < before, "Steam is harmful only after its warning")
	Session.level = 3
	Session.checkpoint = Vector2(120,3200)
	Session.health = 3
	load_level(true)
	await get_tree().create_timer(0.65).timeout
	assert(player.position.y > 3000 and player.fall_limit == 3700)
	assert(player.is_on_floor(), "Vertical level must not use the old 850px fall limit")
	var start_surface = world.surface_y
	world.grace = 0
	await get_tree().create_timer(0.15).timeout
	assert(world.surface_y < start_surface)
	toggle_pause()
	var paused_surface = world.surface_y
	await get_tree().create_timer(0.1).timeout
	assert(world.surface_y == paused_surface)
	toggle_pause()
	# Drowning ends the entire adventure, rather than recovering in the shaft.
	world.surface_y = player.position.y - 15
	await get_tree().physics_frame
	await get_tree().physics_frame
	await get_tree().process_frame
	assert(Session.level == 0 and Session.health == 3)
	# Boss dash damage protection is enforced even at the arena damage entry point.
	test_boss()
	world.start_attacks()
	player.dash_time = 0.1
	world.damage_player()
	assert(world.health == 5)
	player.dash_time = 0
	world.invincible = 0
	world.damage_player()
	assert(world.health == 4)
	Session.playing = false
	if not original_save.is_empty():
		var f = FileAccess.open("user://trashlight.cfg", FileAccess.WRITE)
		f.store_buffer(original_save)
		f.close()
	assert(original_save == FileAccess.get_file_as_bytes("user://trashlight.cfg"))
	print("HARD MODE CHECKS PASSED: dash speed, duration, cooldown, invulnerability; vents; vertical fall limits; rising flood; pause; drowning; checkpoint recovery; climb geometry; boss dash protection")
	await get_tree().create_timer(0.8).timeout
	get_tree().quit()

func select_difficulty(value: int) -> void:
	Session.difficulty = value
	$UI/Title/Easy.text = "[EASY]" if value == 0 else "EASY"
	$UI/Title/Hard.text = "[HARD]" if value == 1 else "HARD"
	$UI/Title/Difficulty.text = "EASY - take a breath." if value == 0 else "HARD - fast flood. 3 boss hearts."

func run_effects_tests() -> void:
	var saved = FileAccess.get_file_as_bytes("user://trashlight.cfg")
	$UI/Title/Hard.pressed.emit()
	assert(Session.difficulty == 1)
	test_boss()
	world.start_attacks()
	world.set_physics_process(false)
	assert(world.health == 3)
	world.attack_index = 4
	world.begin_attack()
	world.spawn_wave()
	assert(world.get_node("Hazards").get_child_count() >= 3)
	var rising = false
	for h in world.get_node("Hazards").get_children():
		if h.get_script() == load("res://scripts/orbital_laser.gd"):
			rising = h.size.y == 650 and h.position.y == 325 and h.travel_velocity == Vector2.ZERO
	assert(rising)
	world.clear_hazards()
	world.expose_fuse()
	player.position = world.fuse.position + Vector2(0,40)
	Session.pulse.emit()
	assert(world.phase == 1 and world.checkpoint_phase == 0)
	world.begin_attack()
	world.health = 1
	world.invincible = 0
	world.damage_player()
	world.retry()
	assert(world.phase == 0 and world.health == 3)
	world.set_physics_process(false)
	var blast = world.spawn_blast(player.position-Vector2(0,20),100)
	blast.warning = 0.2
	world.invincible = 0
	await get_tree().create_timer(0.08).timeout
	assert(not blast.detonated and world.health == 3)
	await get_tree().create_timer(0.2).timeout
	assert(blast.detonated and world.health == 2)
	world.clear_hazards()
	to_menu()
	assert(saved == FileAccess.get_file_as_bytes("user://trashlight.cfg"))
	print("EFFECTS CHECKS PASSED: selector, hard health, orbital lasers, blast warnings/damage, no hard checkpoint, retry and save preservation")
	await get_tree().create_timer(0.8).timeout
	get_tree().quit()

func run_sprite_tests() -> void:
	test_boss()
	world.start_attacks()
	world.set_physics_process(false)
	var frames = load("res://art/fx/effects.tres") as SpriteFrames
	for entry in [["explosion",16],["laser",6],["steam",8],["smoke",10],["hit",8],["muzzle",6]]:
		assert(frames.get_frame_count(entry[0]) == entry[1])
	var fx = load("res://scenes/sprite_fx.tscn").instantiate()
	fx.effect = "explosion"
	world.add_child(fx)
	await get_tree().create_timer(0.2).timeout
	assert(fx.get_node("AnimatedSprite2D").frame > 0)
	await get_tree().create_timer(0.8).timeout
	assert(not is_instance_valid(fx), "One-shot sprites must clean up after playback")
	var laser = world.spawn_orbital(300)
	laser.warning_seconds = 0.1
	await get_tree().create_timer(0.25).timeout
	assert(laser.laser_sprite.visible and laser.position.y == 325 and laser.size.y == 650)
	assert(laser.laser_sprite.sprite_frames.get_animation_loop("strike"))
	world.clear_hazards()
	print("SPRITE CHECKS PASSED: all frame sequences, playback advance, one-shot cleanup, looping lasers, full-height stationary strikes")
	await get_tree().create_timer(0.8).timeout
	get_tree().quit()

func run_orbital_tests() -> void:
	var saved = FileAccess.get_file_as_bytes("user://trashlight.cfg")
	Session.difficulty = 0
	test_boss()
	world.start_attacks()
	world.set_physics_process(false)
	var beam = world.spawn_orbital(576)
	beam.warning_seconds = 0.25
	beam.active_seconds = 2.0
	player.position = Vector2(576,325)
	await get_tree().create_timer(0.12).timeout
	assert(not beam.active and world.health == 5)
	assert(beam.laser_sprite.animation == "charge")
	assert(beam.size.y == 650 and beam.position.y == 325)
	await get_tree().create_timer(0.2).timeout
	assert(beam.active and beam.laser_sprite.animation == "strike")
	assert(world.health == 4)
	for y in [35,325,640]:
		world.health = 5
		world.invincible = 0
		player.dash_time = 0
		player.position = Vector2(576,y)
		player.velocity = Vector2.ZERO
		await get_tree().create_timer(0.06).timeout
		assert(world.health == 4, "Full-height beam must damage at top, middle and floor")
	assert(beam.laser_sprite.sprite_frames.get_frame_count("strike") == 8)
	assert(beam.laser_sprite.sprite_frames.get_frame_count("charge") == 8)
	world.clear_hazards()
	for phase in range(3):
		world.phase = phase
		for attack in [0,1,3,4]:
			world.attack_index = attack
			world.wave = 1
			world.spawn_wave()
			for h in world.get_node("Hazards").get_children():
				if h.get("kind") == "laser":
					assert(h.get_script() == load("res://scripts/orbital_laser.gd"))
			world.clear_hazards()
	assert(saved == FileAccess.get_file_as_bytes("user://trashlight.cfg"))
	print("ORBITAL CHECKS PASSED: charge/strike sprite sequences, harmless charge, top/middle/floor damage, fixed full-height footprint, every boss laser replaced, save preservation")
	await get_tree().create_timer(0.8).timeout
	get_tree().quit()

func run_spike_tests() -> void:
	var saved = FileAccess.get_file_as_bytes("user://trashlight.cfg")
	Session.difficulty = 0
	test_boss()
	world.start_attacks()
	world.set_physics_process(false)
	assert(world.get_node("BossUI/Panel") is Control and not world.get_node("BossUI/Panel") is Panel)
	for name in ["Name","Attack","Dialogue","Cooldown","PauseButton","TitleButton"]:
		assert(not world.get_node("BossUI/Panel/"+name).visible)
	for difficulty in [0,1]:
		Session.difficulty = difficulty
		for phase in range(3):
			world.phase = phase
			for attack in range(5):
				world.attack_index = attack
				world.wave = 1
				world.spawn_wave()
				for h in world.get_node("Hazards").get_children():
					if h.get_script() == load("res://scripts/boss_hazard.gd"):
						assert(h.kind == "spike", "No box/crusher/scrap hazards may remain in boss patterns")
				world.clear_hazards()
	Session.difficulty = 0
	world.phase = 0
	world.wave = 0
	world.spawn_spike_volley(8)
	assert(world.get_node("Hazards").get_child_count() == 8)
	world.clear_hazards()
	Session.difficulty = 1
	world.spawn_spike_volley(12)
	assert(world.get_node("Hazards").get_child_count() == 12)
	world.clear_hazards()
	Session.difficulty = 0
	world.health = 5
	world.invincible = 0
	player.position = Vector2(576,650)
	player.velocity = Vector2.ZERO
	var spike = world.spawn_hazard(Vector2(576,625),Vector2(24,49),0.15,2,Vector2.ZERO,"spike")
	await get_tree().create_timer(0.07).timeout
	assert(world.health == 5 and not spike.active)
	assert(spike.spike_sprite.sprite_frames.get_frame_count("fall") == 4)
	assert(spike.get_node("CollisionShape2D").shape is ConvexPolygonShape2D)
	await get_tree().create_timer(0.15).timeout
	assert(world.health == 4 and spike.active)
	spike.interrupt()
	assert(spike.cancelled)
	world.clear_hazards()
	assert(saved == FileAccess.get_file_as_bytes("user://trashlight.cfg"))
	print("SPIKE CHECKS PASSED: no boss banner, every phase box-free, 8/12 spike volleys, sprite frames, triangular collision, harmless warning, active damage, pulse clearing, save preservation")
	await get_tree().create_timer(0.8).timeout
	get_tree().quit()

func spike_preview() -> void:
	Session.difficulty = 1
	test_boss()
	world.start_attacks()
	world.phase = 2
	world.attack_index = 2
	world.begin_attack()
	world.spawn_wave()
	await get_tree().create_timer(1.3).timeout
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png(ProjectSettings.globalize_path("res://../Trashlight-spikes.png"))
	get_tree().quit()

func run_route_tests() -> void:
	var saved = FileAccess.get_file_as_bytes("user://trashlight.cfg")
	Session.level = 2
	Session.checkpoint = Vector2(2670,582)
	Session.playing = true
	menu = false
	$UI/Title.hide()
	load_level(true)
	assert(world.has_node("SteamVent3") and world.has_node("ExtraMoth"))
	assert(world.get_node("SteamVent3/CollisionShape2D").shape.size == Vector2(76,210))
	Session.fragments.erase(2)
	world.get_node("Exit").entered(player)
	assert(Session.level == 2, "Power cell still required")
	Session.fragments.append(2)
	world.get_node("Exit").entered(player)
	await get_tree().process_frame
	assert(Session.level == 3 and world.has_node("Sludge"), "Power cell alone unlocks the next stage")
	if not saved.is_empty():
		var file = FileAccess.open("user://trashlight.cfg",FileAccess.WRITE)
		file.store_buffer(saved)
		file.close()
	print("ROUTE CHECKS PASSED: restored hazards, large geyser collision, power-cell requirement and direct transition to Flood Shaft")
	await get_tree().create_timer(0.3).timeout
	get_tree().quit()

func restart_after_death() -> void:
	new_game()
	show_message("RUN ENDED — back to the beginning. Only the final boss has a checkpoint.")

func run_death_tests() -> void:
	var saved = FileAccess.get_file_as_bytes("user://trashlight.cfg")
	Session.difficulty = 0
	new_game()
	# Lamps are decorative: no healing, relocation or save checkpoint.
	Session.health = 2
	var spawn = Session.checkpoint
	world.get_node("FirstLantern").entered(player)
	assert(Session.health == 2 and Session.checkpoint == spawn)
	# Ordinary nonfatal damage still uses hearts.
	Session.health = 3
	player.invincible = 0
	player.hurt()
	assert(Session.health == 2 and Session.level == 0 and Session.playing)
	for level_index in range(4):
		Session.level = level_index
		Session.checkpoint = Vector2(120,3200) if level_index == 3 else Vector2(100,530)
		Session.fireflies = 19
		Session.fragments.assign([0,1])
		Session.collected.assign(["dummy-pickup"])
		Session.health = 1
		load_level(true)
		player.invincible = 0
		player.hurt()
		await get_tree().process_frame
		await get_tree().process_frame
		assert(Session.level == 0 and Session.health == 3 and not Session.at_boss)
		assert(Session.fireflies == 0 and Session.fragments.is_empty() and Session.collected.is_empty())
		assert(player.position.x < 200)
	# A fall is fatal even with hearts remaining.
	Session.level = 2
	Session.checkpoint = Vector2(100,530)
	Session.health = 3
	load_level(true)
	player.hurt(true)
	await get_tree().process_frame
	await get_tree().process_frame
	assert(Session.level == 0 and Session.health == 3)
	# No quit/resume or stage transition may serialize a mid-run checkpoint.
	Session.level = 2
	Session.fireflies = 20
	Session.fragments.assign([0,1])
	Session.save_run()
	var cfg = ConfigFile.new()
	assert(cfg.load("user://trashlight.cfg") == OK)
	assert(cfg.get_value("save","level") == 0)
	assert(cfg.get_value("save","fragments").is_empty())
	# Boss arrival is saved, and every retry begins at fuse one in both modes.
	Session.level = 3
	Session.fragments.assign([0,1,2,3])
	advance()
	await get_tree().process_frame
	assert(Session.at_boss and in_boss and world.phase == 0)
	for difficulty in [0,1]:
		Session.difficulty = difficulty
		world.phase = 2
		world.state = "attack"
		world.health = 1
		world.invincible = 0
		world.damage_player()
		assert(world.state == "dead")
		world.retry()
		assert(world.phase == 0 and Session.at_boss)
	to_menu()
	continue_game()
	assert(in_boss and world.phase == 0)
	assert(cfg.load("user://trashlight.cfg") == OK)
	assert(cfg.get_value("save","at_boss") and cfg.get_value("save","boss_checkpoint") == 0)
	if not saved.is_empty():
		var file = FileAccess.open("user://trashlight.cfg",FileAccess.WRITE)
		file.store_buffer(saved)
		file.close()
	print("DEATH CHECKS PASSED: decorative lamps, ordinary heart damage, full resets from all four levels, fatal falls, cleared pickups, no mid-run save checkpoint, boss-arrival save, fresh boss retries and continue")
	await get_tree().create_timer(0.8).timeout
	get_tree().quit()
