extends StaticBody2D
var time = 0.0
func _ready() -> void:
	Session.pulse.connect(reveal)
	collision_layer = 0
func reveal() -> void:
	time = 4.0 if Session.difficulty == 1 else 6.0
	collision_layer = 1
func _process(dt: float) -> void:
	time = maxf(0, time - dt)
	if time <= 0:
		collision_layer = 0
	$Art.modulate.a = (0.5 + sin(time * 20) * 0.2 if time < 1.5 else 1.0) if time > 0 else 0.17
