extends Area2D
@export var fragment = false
@export var pickup_id = ""
var age = 0.0
var home = 0.0
func _ready() -> void:
	home = position.y
	if pickup_id in Session.collected:
		queue_free()
	body_entered.connect(collect)
func _process(dt: float) -> void:
	age += dt
	$Art.position.y = sin(age * 2.5 + position.x) * 5
	$Art.rotation = sin(age) * 0.08 if fragment else 0.0
func collect(body: Node2D) -> void:
	if Session.playing and body.visible and body.is_in_group("player"):
		Session.collect(pickup_id, fragment)
		queue_free()
