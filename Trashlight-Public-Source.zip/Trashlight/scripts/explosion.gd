extends Node2D
## Telegraph first; expanding blast then embers. Native world-space effect.
@export var radius = 115.0
@export var warning = 1.0
const SPRITE_FX = preload("res://scenes/sprite_fx.tscn")
var age = 0.0
var detonated = false
func _ready() -> void:
	z_index = 7
func _physics_process(dt: float) -> void:
	if not Session.playing:
		return
	age += dt
	if age >= warning and not detonated:
		detonated = true
		Session.sound("explosion")
		var fx = SPRITE_FX.instantiate()
		fx.effect = "explosion"
		fx.scale = Vector2.ONE * radius / 32.0
		add_child(fx)
	if detonated and age < warning + 0.4:
		var p = get_tree().get_first_node_in_group("player")
		if p and p.global_position.distance_to(global_position) < radius + 12:
			p.hurt()
	if age > warning + 1.0:
		queue_free()
	queue_redraw()
func _draw() -> void:
	if detonated:
		return
	var progress = clampf(age / warning,0,1)
	var danger = Color(1,lerpf(0.78,0.18,progress),0.1,0.9)
	var flash = 0.07 + (0.07 if int(age*12)%2 == 0 else 0.0)
	# Fixed blast footprint, segmented hazard tape and a closing countdown ring.
	draw_circle(Vector2.ZERO,radius,Color(0.9,0.2,0.04,flash))
	for i in range(16):
		var a = float(i)*TAU/16
		var b = a+TAU/16*0.63
		draw_arc(Vector2.ZERO,radius,a,b,5,danger,4,false)
		var at = Vector2.from_angle(a)*(radius-8)
		draw_line(at,at+Vector2.from_angle(a+0.6)*9,danger,2)
	var remaining = TAU*(1-progress)
	if remaining > 0.02:
		draw_arc(Vector2.ZERO,radius+9,-PI/2,-PI/2+remaining,64,Color(1,0.85,0.4,0.85),2,false)
	for side in [-1,1]:
		var at = Vector2(side*12,0)
		draw_line(at+Vector2(0,-10),at+Vector2(0,10),danger,2)
		draw_line(Vector2(-10,side*12),Vector2(10,side*12),danger,2)
	draw_line(Vector2(0,-7),Vector2(0,1),Color("fff0b7"),3)
	draw_rect(Rect2(-1,5,3,3),Color("fff0b7"))
